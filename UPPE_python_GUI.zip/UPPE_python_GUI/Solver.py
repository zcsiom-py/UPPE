import numpy as np
import enviroment as env
from mkl_fft import fft, ifft
import matplotlib.pyplot as plt
from base_function import calArea
# from numba.experimental import jitclass
from numba import jit
import time
import cython
from tool_function import cython_trapz
import os
import sys

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

c = 2.997924580105029e8
Av = 6.02214179e23
epsi0 = 8.854187817e-12
T0 = 273.15
P0 = 1.0


# nframe = 300
# n = 2 ** 15
# dt = 0.05e-15
# dz = 1e-4
# tol = 1e-4
#
# # Base solver parameters
# lamlim = (110e-9, 4000e-9)
# t = np.arange(-n / 2, n / 2) * dt
# dw = 2 * np.pi / (n * dt)
# w = np.fft.fftshift(np.arange(-n / 2, n / 2) * dw)
# solver_param = env.solverParam(t=t, w=w, lamlim=lamlim)
#
# # gas parameters
# gas_instance = env.gas(
#     gas_type='helium',
#     ionorder=1,
#     pressure=3,
#     ionization_type='PPT',
#     temp=294.15
# )
#
# # Fiber parameters
# radius = 50e-6
# L = 50e-2
# beta_order = 2
# gasPCF_instance = env.gasPCF(radius, beta_order, gas_instance, solver_param, alpha_flag=1)
# plt.figure()
# plt.plot(gasPCF_instance.beta_curves[1, :])
# ax = plt.gca()
# ax1 = ax.twinx()
# ax1.plot(gasPCF_instance.beta_curves[2, :], color='red')
# plt.show()
#
# # Pulse parameters
# pulse_instance = env.pulse(radius, solver_param, gas_instance.n0,
#                            tfwhm=10e-15,
#                            Q=60e-6,
#                            wl0=800e-9,
#                            type='gauss')
#
# # plt.figure()
# # plt.plot(solver_param.t, pulse_instance.E0t)
# # plt.show()
#
#
# P, Ne, Na, Ni = env.electron_polar(solver_param, pulse_instance.E0t, gas_instance, gasPCF_instance)
# plt.figure()
# plt.plot(P[15000:20000], lw=0.8)
# plt.show()
# z = np.linspace(0, L, num=nframe)

class parameterSetter:
    def __init__(self,
                 n=2 ** 15,
                 dt=0.05e-15,
                 dz=1e-4,
                 tol=1e-4,
                 lamlim=(110e-9, 4000e-9),
                 gas_type='helium',
                 ionorder=1,
                 pressure=3,
                 ionization_type='PPT',
                 temp=294.15,
                 L=50e-2,
                 radius=50e-6,
                 beta_order=2,
                 tfwhm=10e-15,
                 Q=60e-6,
                 wl0=800e-9,
                 type='gauss'
                 ):
        self.tol = tol  # 1
        t = np.arange(-n / 2, n / 2) * dt
        dw = 2 * np.pi / (n * dt)
        w = np.fft.fftshift(np.arange(-n / 2, n / 2) * dw)
        self.solver_param = env.solverParam(t=t, w=w, lamlim=lamlim)  # 3
        self.dz = dz  # 2
        self.gas_instance = env.gas(
            gas_type=gas_type,
            ionorder=ionorder,
            pressure=pressure,
            ionization_type=ionization_type,
            temp=temp
        )  # 4
        self.gasPCF_instance = env.gasPCF(radius, beta_order, self.gas_instance,
                                          self.solver_param, alpha_flag=1)  # 5
        self.L = L  # 6
        self.pulse_instance = env.pulse(radius, self.solver_param, self.gas_instance.n0,
                                        tfwhm=tfwhm,
                                        Q=Q,
                                        wl0=wl0,
                                        type=type)


class solveMange(parameterSetter):
    def __init__(self,
                 n=2 ** 15,
                 dt=0.05e-15,
                 dz=1e-4,
                 tol=1e-4,
                 lamlim=(110e-9, 4000e-9),
                 gas_type='helium',
                 ionorder=1,
                 pressure=3,
                 ionization_type='PPT',
                 temp=294.15,
                 L=50e-2,
                 radius=50e-6,
                 beta_order=2,
                 tfwhm=10e-15,
                 Q=60e-6,
                 wl0=800e-9,
                 type='gauss'
                 ):
        super().__init__(n, dt, dz, tol, lamlim, gas_type, ionorder, pressure, ionization_type, temp, L, radius,
                         beta_order,
                         tfwhm,
                         Q,
                         wl0,
                         type)
        self.nframe = 300
        self.num = len(self.solver_param.t)
        self.Etframe = np.zeros((self.nframe + 1, self.num), dtype=np.complex64)
        self.Efframe = np.zeros((self.nframe + 1, self.num), dtype=np.complex64)
        self.Et = self.pulse_instance.E0t
        self.Ef = self.pulse_instance.E0f
        self.Etframe[0, :] = self.pulse_instance.E0t
        self.Efframe[0, :] = self.pulse_instance.E0f
        self.Neframe = np.zeros((self.nframe + 1, self.num))
        self.energy = np.zeros(self.nframe + 1)
        self.peakpower = np.zeros(self.nframe + 1)
        self.maxIonrate = np.zeros(self.nframe + 1)
        self.energy[0] = cython_trapz(np.real(
            self.pulse_instance.E0t ** 2), self.solver_param.t) * c * epsi0 * self.gas_instance.n0 * calArea(
            self.gasPCF_instance.fiber_radius)
        self.peakpower[0] = np.max(np.real(self.pulse_instance.E0t ** 2)) * c * epsi0 * self.gas_instance.n0 * calArea(
            self.gasPCF_instance.fiber_radius) / 2

        P, Ne, Na, Ni = env.electron_polar(self.solver_param, self.pulse_instance.E0t,
                                           self.gas_instance,
                                           self.gasPCF_instance)
        self.maxIonrate[0] = np.max(Ne) / self.gasPCF_instance.N0
        self.Neframe[0, :] = Ne
        self.dz = dz
        beta = self.gasPCF_instance.beta_curves[0, :] - self.gasPCF_instance.betap[1] * self.solver_param.w
        self.linop = -self.gasPCF_instance.alpha / 2 + 1j * beta

        # plt.figure()
        # plt.plot(np.imag(self.linop))
        # plt.show()

    # @cython.compile

    def solve(self):
        z = np.linspace(0, self.L, self.nframe, endpoint=True)
        propagedlength = 0
        countframe = 1
        while propagedlength < self.L:
            # os.system('cls')
            print('% 6.2f%%' % (propagedlength * 100.0 / self.L))
            # sys.stdout.flush()
            storeframe = False
            if self.dz + propagedlength >= z[countframe]:
                orig_dz = self.dz
                self.dz = z[countframe] - propagedlength
                storeframe = True
            Ecoarse, Efine = self.rk4ipsolv()
            delta = np.sqrt(np.sum(np.abs(Efine - Ecoarse) ** 2)) / np.sqrt(np.sum(np.abs(Efine) ** 2))
            if delta > 2 * self.tol or np.isnan(delta):
                self.dz = self.dz / 2.0
                vaild = False
            else:
                self.Ef = (16 / 15) * Efine - 1 / 15 * Ecoarse
                self.Et = np.real(fft(self.Ef))
                propagedlength = propagedlength + self.dz
                vaild = True
                if delta < self.tol / 2:
                    self.dz = self.dz * (2 ** (1.0 / 5))
                elif delta > self.tol:
                    self.dz = self.dz / (2 ** (1.0 / 5))
            if storeframe and vaild:
                self.Etframe[countframe, :] = self.Et
                self.Efframe[countframe, :] = self.Ef
                self.energy[countframe] = cython_trapz(np.real(
                    self.Et ** 2), self.solver_param.t) * c * epsi0 * self.gas_instance.n0 * calArea(
                    self.gasPCF_instance.fiber_radius)
                self.peakpower[countframe] = np.max(np.real(self.Et ** 2)) * c * epsi0 * self.gas_instance.n0 * calArea(
                    self.gasPCF_instance.fiber_radius)
                P, Ne, Na, Ni = env.electron_polar(self.solver_param, self.Et,
                                                   self.gas_instance,
                                                   self.gasPCF_instance)
                self.maxIonrate[countframe] = np.max(Ne) / self.gasPCF_instance.N0
                self.Neframe[countframe, :] = Ne
                countframe = countframe + 1
                self.dz = orig_dz

    def rk4ipsolv(self):
        fR = self.gasPCF_instance.fR
        chi3 = self.gasPCF_instance.chi3
        # halfstep = np.exp(self.dz / 2 * self.linop)
        # quarterstep = np.exp(self.dz / 4 * self.linop)
        halfstep, quarterstep = cal_step(self.dz, self.linop)
        Ehalf = halfstep * self.Ef
        Equarter = quarterstep * self.Ef
        Eip = Ehalf
        nonlinOne = self.dz * (1j * self.solver_param.w / (2 * c * self.gasPCF_instance.neff))
        nonlinHalf = 0.5 * nonlinOne
        P, Ne, Na, Ni = env.electron_polar(self.solver_param, self.Et,
                                           self.gas_instance,
                                           self.gasPCF_instance)
        prek1 = ifft(kerr_polar(fR, chi3, self.Et) + P)
        k1 = nonlinOne * prek1
        k1 = halfstep * k1
        Ehalf2 = np.real(fft(Eip + k1 / 2))
        P, Ne, Na, Ni = env.electron_polar(self.solver_param, Ehalf2,
                                           self.gas_instance,
                                           self.gasPCF_instance)
        k2 = nonlinOne * ifft(kerr_polar(fR, chi3, Ehalf2) + P)
        Ehalf3 = np.real(fft(Eip + k2 / 2))
        P, Ne, Na, Ni = env.electron_polar(self.solver_param, Ehalf3,
                                           self.gas_instance,
                                           self.gasPCF_instance)
        k3 = nonlinOne * ifft(kerr_polar(fR, chi3, Ehalf3) + P)
        Ehalf4 = np.real(fft(halfstep * (Eip + k3)))
        P, Ne, Na, Ni = env.electron_polar(self.solver_param, Ehalf4,
                                           self.gas_instance,
                                           self.gasPCF_instance)
        k4 = nonlinOne * ifft(kerr_polar(fR, chi3, Ehalf4) + P)

        Ecoarse = halfstep * (Eip + k1 / 6 + k2 / 3 + k3 / 3) + k4 / 6

        Eip = Equarter
        k1 = nonlinHalf * prek1
        k1 = quarterstep * k1
        Ehalf2 = np.real(fft(Eip + k1 / 2))
        P, Ne, Na, Ni = env.electron_polar(self.solver_param, Ehalf2,
                                           self.gas_instance,
                                           self.gasPCF_instance)
        k2 = nonlinHalf * ifft(kerr_polar(fR, chi3, Ehalf2) + P)
        Ehalf3 = np.real(fft(Eip + k2 / 2))
        P, Ne, Na, Ni = env.electron_polar(self.solver_param, Ehalf3,
                                           self.gas_instance,
                                           self.gasPCF_instance)
        k3 = nonlinHalf * ifft(kerr_polar(fR, chi3, Ehalf3) + P)
        Ehalf4 = np.real(fft(quarterstep * (Eip + k3)))
        P, Ne, Na, Ni = env.electron_polar(self.solver_param, Ehalf4,
                                           self.gas_instance,
                                           self.gasPCF_instance)
        k4 = nonlinHalf * ifft(kerr_polar(fR, chi3, Ehalf4) + P)
        Efine = quarterstep * (Eip + k1 / 6 + k2 / 3 + k3 / 3) + k4 / 6

        Eip = quarterstep * Efine
        Efine = np.real(fft(Efine))

        P, Ne, Na, Ni = env.electron_polar(self.solver_param, Efine,
                                           self.gas_instance,
                                           self.gasPCF_instance)
        k1 = nonlinHalf * ifft(kerr_polar(fR, chi3, Efine) + P)
        k1 = quarterstep * k1
        Ehalf2 = np.real(fft(Eip + k1 / 2))
        P, Ne, Na, Ni = env.electron_polar(self.solver_param, Ehalf2,
                                           self.gas_instance,
                                           self.gasPCF_instance)
        k2 = nonlinHalf * ifft(kerr_polar(fR, chi3, Ehalf2) + P)
        Ehalf3 = np.real(fft(Eip + k2 / 2))
        P, Ne, Na, Ni = env.electron_polar(self.solver_param, Ehalf3,
                                           self.gas_instance,
                                           self.gasPCF_instance)
        k3 = nonlinHalf * ifft(kerr_polar(fR, chi3, Ehalf3) + P)
        Ehalf4 = np.real(fft(quarterstep * (Eip + k3)))
        P, Ne, Na, Ni = env.electron_polar(self.solver_param, Ehalf4,
                                           self.gas_instance,
                                           self.gasPCF_instance)
        k4 = nonlinHalf * ifft(kerr_polar(fR, chi3, Ehalf4) + P)

        Efine = quarterstep * (Eip + k1 / 6 + k2 / 3 + k3 / 3) + k4 / 6
        return Ecoarse, Efine


@jit(nopython=True)
def kerr_polar(fR, chi3, Et):
    return (1 - fR) * chi3 * Et ** 3


@jit(nopython=True)
def cal_step(dz, linop):
    halfstep = np.exp(dz / 2 * linop)
    quarterstep = np.exp(dz / 4 * linop)
    return halfstep, quarterstep
