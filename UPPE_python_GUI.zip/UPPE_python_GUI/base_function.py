import numpy as np
from scipy.special import jn_zeros, jv, gamma

c = 2.99792458e8


def calArea(radius):
    r = np.linspace(0, radius, 2 ** 10)
    u11 = jn_zeros(0, 1)
    field = jv(0, u11 * r / radius)
    Aeff = 2 * np.pi * (np.trapz(field ** 2 * r, r)) ** 2 / np.trapz(field ** 4 * r, r)
    return Aeff


def calArea_empirical(radius, C, g, n_tubes):
    Mf = 0.75 * C / (1 - 0.5 * np.exp(-0.245 * n_tubes))
    Aeff = Mf * radius ** 2 * np.exp((g * 1e6 / 22) ** 2.5)
    return Aeff


def frogread(filepath):
    data = np.loadtxt(filepath)
    wl = data[:, 0] * 1e-9
    w = 2 * np.pi * c / wl
    intensity_frog = data[:, 1]
    phase_frog = data[:, 2]
    amplitude_frog = np.sqrt(intensity_frog)
    return w, amplitude_frog, phase_frog
# print(calArea_empirical(1, 0.5, 1e-12, 6))

def solve():
    pass



