import pickle
from dataclasses import dataclass


@dataclass
class gas_data:
    B1: float
    B2: float
    C1: float
    C2: float
    q: float
    m: float
    chi: float


he = gas_data(4977.77e-8, 1856.94e-8, 28.54e-6, 7.760e-3, 0.1786, 4.002602e-3, 3.43e-28)
ne = gas_data(9154.48e-8, 4018.63e-8, 656.97e-6, 5.728e-3, 0.9003, 20.1797e-3, 6.174e-28)
ar = gas_data(20332.29e-8, 34458.31e-8, 206.12e-6, 8.066e-3, 1.7841, 39.948e-3, 80.605e-28)
kr = gas_data(26102.88e-8, 56946.82e-8, 2.01e-6, 10.043e-3, 3.7387, 83.798e-3, 2.1952e-26)
xe = gas_data(103701.61e-8, 31228.61e-8, 12750e-6, 0.561e-3, 0.9003, 131.293e-3, 6.45526e-26)

gas_data_list = {
    "helium": he,
    'neon': ne,
    'argon': ar,
    'krypton': kr,
    'xenon': xe
}

# with open('gas_data.txt', 'wb') as f:
#     pickle.dump(gas_data_record, f)