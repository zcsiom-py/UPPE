import Solver
import time
import matplotlib.pyplot as plt
import numpy as np
from mkl_fft import fft

c = 2.997924580105029e8
epsi0 = 8.854187817e-12
main_solver = Solver.solveMange(gas_type='neon',
                                ionorder=1,
                                pressure=2,
                                L=50e-2,
                                radius=50e-6,
                                tfwhm=10e-15,
                                Q=60e-6,
                                type='gauss'
                                )

start = time.time()
main_solver.solve()
end = time.time()
print(end - start)
t = main_solver.solver_param.t
tau = t[(t > -1000e-15) & (t < 1000e-15)]
wl = 2 * np.pi * c / main_solver.solver_param.w
plt.figure()
plt.subplot(121)
plt.plot(tau * 1e15, np.abs(main_solver.Etframe[-2, (t > -1000e-15) & (
        t < 1000e-15)]) ** 2 * c * epsi0 * main_solver.gas_instance.n0 / 2 * 1e-16,
         lw=0.5)

temp_f = main_solver.Efframe[-2, :]
temp_f[int(len(main_solver.solver_param.t) / 2):] = 0
Envframe = 2 * fft(temp_f)
plt.plot(tau * 1e15, np.abs(Envframe[(t > -1000e-15) & (
        t < 1000e-15)]) ** 2 * c * epsi0 * main_solver.gas_instance.n0 / 2 * 1e-16,
         lw=0.5, color='r')

plt.xlim([-100, 100])
plt.subplot(122)
spec = np.abs(main_solver.Efframe[-2, (wl >= 110e-9) & (wl <= 4000e-9)] ** 2 / wl[
    (wl >= 110e-9) & (wl <= 4000e-9)] ** 2)
plt.plot(wl[(wl >= 110e-9) & (wl <= 4000e-9)] * 1e9, spec / np.max(spec))
plt.xlim([110, 1200])
plt.ylim([0, 1])
plt.show()
