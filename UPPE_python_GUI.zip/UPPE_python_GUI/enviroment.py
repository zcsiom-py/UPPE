import numpy as np
from scipy.special import gamma
from dataclasses import dataclass
from scipy.special import jn_zeros
from scipy import interpolate
import scipy.io as scio
from gas_data_gen import gas_data_list
import matplotlib.pyplot as plt
from base_function import calArea, frogread
# from scipy.integrate import cumulative_trapezoid
from mkl_fft import ifft, fft
from scipy.interpolate import CubicSpline
from tool_function import real_cumtrapz, complex_cumtrapz
from scipy.interpolate import PPoly
from numba import jit


# @dataclass
# class gas_data:
#     B1: float
#     B2: float
#     C1: float
#     C2: float
#     q: float
#     m: float
#     chi: float


@dataclass
class solverParam:
    w: np.ndarray  # Omega of laser
    t: np.ndarray  # time window
    lamlim: tuple  # wavelength window


# with open('gas_data.txt', 'rb') as f:
#     gas_data_list = pickle.load(f)

c = 2.997924580105029e8
Av = 6.02214179e23
epsi0 = 8.854187817e-12
T0 = 273.15
P0 = 1.0

gas_transfer = {
    'helium': 'He',
    'neon': 'Ne',
    'argon': 'Ar',
    'krypton': 'Kr',
    'xenon': 'Xe'
}


class gas:
    def __init__(self, gas_type='helium', ionorder=1, pressure=3, ionization_type='ADK', temp=294.15):
        self.temp = temp
        self.ionorder = ionorder
        self.gas_type = gas_type
        self.w_p = None
        self.I_p = None
        self.Cn = None
        self.n_star = None
        self.n0 = 1
        self.pressure = pressure / 1.01325
        self.temp_fun = None
        self.refractive_index()
        if self.ionorder > 0.1:
            if ionization_type == 'ADK':
                self.ADK_ionization()
            elif ionization_type == 'PPT':
                self.PPT_ionization()

    def ADK_ionization(self):
        h = 6.62606896e-34
        hbar = h / 2 / np.pi
        e = 1.60217646e-19
        I_H = 13.59844 * e
        if self.ionorder > 0.1:
            if self.gas_type == 'helium':
                I_p = np.array([24.58741, 54.41778, np.inf, np.inf, np.inf]) * e
            elif self.gas_type == 'neon':
                I_p = np.array([21.5646, 40.96328, 63.45, 97.12, 126.21]) * e
            elif self.gas_type == 'argon':
                I_p = np.array([15.75962, 27.62967, 40.74, 59.81, 75.02]) * e
            elif self.gas_type == 'krypton':
                I_p = np.array([13.99961, 24.35985, 36.950, 52.5, 64.7]) * e
            elif self.gas_type == 'xenon':
                I_p = np.array([12.1298, 21.20979, 32.1230, np.inf, np.inf]) * e
            else:
                print("Not support gas")
            z = np.arange(1, int(self.ionorder) + 1)
            self.I_p = I_p[z - 1]
            self.n_star = z * (I_H / self.I_p) ** 0.5
            self.w_p = self.I_p / hbar
            self.Cn = self.w_p * (2 ** (2 * self.n_star)) / (self.n_star * gamma(self.n_star + 1) * gamma(self.n_star))

    def refractive_index(self, centerwavelenth=800e-9):
        wl = centerwavelenth * 1e6
        B1 = gas_data_list[self.gas_type].B1
        B2 = gas_data_list[self.gas_type].B2
        C1 = gas_data_list[self.gas_type].C1
        C2 = gas_data_list[self.gas_type].C2
        T0 = 273.15
        P0_sellmier = 1.0 / 1.01325
        N_sellmier = (self.pressure * T0) / self.temp / P0_sellmier
        self.n0 = np.sqrt(1 + N_sellmier * (B1 * wl ** 2 / (wl ** 2 - C1) + B2 * wl ** 2 / (wl ** 2 - C2)))

    def PPT_ionization(self):
        h = 6.62606896e-34
        e = 1.60217646e-19
        if self.ionorder > 0.1:
            if self.gas_type == 'helium':
                I_p = np.array([24.58741, 54.41778, np.inf, np.inf, np.inf]) * e
            elif self.gas_type == 'neon':
                I_p = np.array([21.5646, 40.96328, 63.45, 97.12, 126.21]) * e
            elif self.gas_type == 'argon':
                I_p = np.array([15.75962, 27.62967, 40.74, 59.81, 75.02]) * e
            elif self.gas_type == 'kry[ton':
                I_p = np.array([13.99961, 24.35985, 36.950, 52.5, 64.7]) * e
            elif self.gas_type == 'xenon':
                I_p = np.array([12.1298, 21.20979, 32.1230, np.inf, np.inf]) * e
            else:
                print("Not support gas")
            z = np.arange(1, int(self.ionorder) + 1)
            self.I_p = I_p[z - 1]
            self.Cn = self.n0
            w_p = np.zeros((12000, int(self.ionorder)))
            data_temp = np.loadtxt(r'PPT_rate_%s_1.txt' % gas_transfer[self.gas_type])
            w_p[:, 0] = data_temp[:, 1]
            self.w_p = w_p
            self.n_star = data_temp[:, 0]
            indx = np.argsort(self.n_star)
            new_n_star = self.n_star[indx]
            new_w_p = self.w_p[indx, 0]
            _, indx = np.unique(new_n_star, return_index=True)

            xaxis, yvalue = new_n_star[indx], new_w_p[indx]
            fun = CubicSpline(xaxis, yvalue)
            poly_instance = PPoly.construct_fast(fun.c, fun.x)
            self.temp_fun = poly_instance.__call__
            # self.temp_fun = lambda x: np.interp(x, xaxis, yvalue)


class gasPCF:
    def __init__(self, fiber_radius,
                 beta_order,
                 fillgas,
                 solverparam, wl0=800e-9, alpha_flag=0):
        self.gas = fillgas
        self.wl0 = wl0
        self.beta_order = beta_order
        self.fiber_radius = fiber_radius
        self.solverparam = solverparam
        self.beta_curves = None
        self.betap = None
        self.zdf = None
        self.chi3 = None
        self.neff = None
        self.n0 = None
        self.fR = 0
        self.hR = 0
        self.hRf = 0
        self.N0 = None
        self.noblegas = None
        self.n_gas = None
        self.alpha = 0
        self.alpha_flag = alpha_flag
        self.paraSet()
        self.lossSet()

    def paraSet(self):
        num = len(self.solverparam.w)
        w0 = 2 * np.pi * c / self.wl0
        dw = abs(self.solverparam.w[1] - self.solverparam.w[0])
        B1 = gas_data_list[self.gas.gas_type].B1
        B2 = gas_data_list[self.gas.gas_type].B2
        C1 = gas_data_list[self.gas.gas_type].C1
        C2 = gas_data_list[self.gas.gas_type].C2
        u11 = jn_zeros(0, 1)
        P0_sellmier = 1.0 / 1.01325
        N_sellmier = (self.gas.pressure * 273.15) / self.gas.temp / P0_sellmier
        wl = (2 * np.pi * c / self.solverparam.w) * 1e6

        self.n_gas = np.sqrt(1 + N_sellmier * (B1 * wl ** 2 / (wl ** 2 - C1) + B2 * wl ** 2 / (wl ** 2 - C2)))

        self.n0 = self.gas.n0
        self.beta_curves = np.zeros((self.beta_order + 1, len(self.solverparam.w)))
        n_gas = self.n_gas + (0 + 0j)
        neff = np.sqrt(n_gas ** 2 - (u11 * c / (self.solverparam.w * self.fiber_radius)) ** 2)

        self.beta_curves[0, :] = np.real(self.solverparam.w / c * neff)
        self.beta_curves[0, 0] = np.max(self.beta_curves[0, 1:])

        # fun_temp = CubicSpline(self.solverparam.w[indx], (self.beta_curves[0, indx]) / dw)
        # fun_temp.derivative()
        for i in range(1, self.beta_order + 1):
            # fun_temp = interpolate.interp1d(self.solverparam.w, np.gradient(self.beta_curves[i - 1, :]) / dw,
            #                                 kind='cubic')
            self.beta_curves[i, :] = np.gradient(self.beta_curves[i - 1, :]) / dw
        # indx_keep = np.logical_and(wl/1e6 > self.solverparam.lamlim[0], wl/1e6 < self.solverparam.lamlim[1])
        # indx_remove = np.logical_not(indx_keep)
        indx = np.arange(0, num)
        indx_condition = np.logical_or(np.abs(self.solverparam.w) > 2 * np.pi * c / self.solverparam.lamlim[0],
                                       np.abs(self.solverparam.w) < 2 * np.pi * c / self.solverparam.lamlim[1])
        removei = indx[indx_condition]
        keepi = np.setdiff1d(indx, removei)
        for i in range(self.beta_order + 1):
            self.beta_curves[i, removei] = np.max(np.abs(self.beta_curves[i, keepi]))

        for i in range(1, self.beta_order + 1):
            fun_temp = interpolate.interp1d(self.solverparam.w, self.beta_curves[i, :], kind='cubic')
            new_cureves = fun_temp(self.solverparam.w)
            self.beta_curves[i, :] = new_cureves

        betap = np.zeros(self.beta_order + 1)
        for i in range(self.beta_order + 1):
            fun_temp = interpolate.interp1d(self.solverparam.w[1:int(num / 2)], self.beta_curves[i, 1:int(num / 2)])
            betap[i] = fun_temp(w0)
        self.betap = betap
        self.neff = c * self.beta_curves[0, :] / self.solverparam.w
        self.noblegas = True
        q = gas_data_list[self.gas.gas_type].q
        m = gas_data_list[self.gas.gas_type].m
        chi = gas_data_list[self.gas.gas_type].chi
        self.chi3 = (self.gas.pressure * 273.15) / self.gas.temp / 1 * 4 * chi
        self.N0 = Av * q / m * (self.gas.pressure * 273.15) / self.gas.temp / 1
        dispersion = self.beta_curves[2, 1:int(num / 2)]
        lam_temp = 2 * np.pi * c / self.solverparam.w[1:int(num / 2)]
        indx = np.logical_and(lam_temp > self.solverparam.lamlim[0], lam_temp < self.solverparam.lamlim[1])
        dispersion = dispersion[indx]
        lam = lam_temp[indx]

    def lossSet(self):
        u11 = jn_zeros(0, 1)
        if self.alpha_flag != 0:
            data = scio.loadmat("PMM_n.mat")
            PMM_n = data["PMM_n"]
            alpha = np.ones_like(self.solverparam.w)
            wl = 2 * np.pi * c / self.solverparam.w
            N = len(PMM_n)
            pmm = np.zeros((2 * N, 2))
            pmm[0:N, 0] = -PMM_n[:, 0]
            pmm[0:N, 1] = PMM_n[:, 1]
            pmm[N:2 * N, 0] = np.flip(PMM_n[:, 0])
            pmm[N:2 * N, 1] = np.flip(PMM_n[:, 1])
            indx = np.argsort(pmm[:, 0])
            # np.interp(wl * 1e6,pmm[indx, 0], pmm[indx, 1])
            # fun_temp = interpolate.interp1d(pmm[indx, 0], pmm[indx, 1], kind='linear')
            # n_glass = fun_temp(wl * 1e6)
            n_glass = np.interp(wl * 1e6, pmm[indx, 0], pmm[indx, 1])
            indx = np.logical_and(np.abs(wl) > self.solverparam.lamlim[0], np.abs(wl) < self.solverparam.lamlim[1])
            v = n_glass / self.n_gas
            alpha[indx] = (u11 / 2 / np.pi) ** 2 * wl[indx] ** 2 / self.fiber_radius ** 3 * (
                    v[indx] ** 2 + 1) / np.sqrt(
                v[indx] ** 2 - 1)

            self.alpha = alpha


class pulse:
    def __init__(self, radius, solveparam, n0,
                 tfwhm=10e-15, Q=50e-6, wl0=800e-9, type='gauss'):
        w0 = 2 * np.pi * c / wl0
        Ieff = Q / calArea(radius)
        if type == 'gauss':
            t0 = tfwhm / (2 * np.log(2) ** 0.5)
            P0 = Ieff * 2 / (c * epsi0 * n0) / (t0 * np.sqrt(np.pi))
            A0 = np.sqrt(P0) * np.exp(-solveparam.t ** 2 / (2 * t0 ** 2))
            self.E0t = 0.5 * (A0 * np.exp(-1j * w0 * solveparam.t) + np.conj(A0) * np.exp(1j * w0 * solveparam.t))
            self.E0f = ifft(self.E0t)
        elif type == 'sech':
            t0 = tfwhm / (2 * np.log(1 + np.sqrt(2)))
            P0 = Ieff * 2 / (c * epsi0 * n0) / (2 * t0)
            A0 = np.sqrt(P0) * 1 / np.cosh(solveparam.t / t0)
            self.E0t = 0.5 * (A0 * np.exp(-1j * w0 * solveparam.t) + np.conj(A0) * np.exp(1j * w0 * solveparam.t))
            self.E0f = ifft(self.E0t)
        elif type != 'gauss' and type != 'sech':
            w_frog, amplitude_frog, phase_frog = frogread(type)
            fun_temp = interpolate.interp1d(w_frog, amplitude_frog, kind='cubic')
            amplitude = fun_temp(solveparam.w)
            indx = np.logical_and(solveparam.w >= np.min(w_frog), solveparam.w <= np.max(w_frog))
            amplitude = np.zeros_like(solveparam.w)
            amplitude[indx] = fun_temp(solveparam.w[indx])
            fun_temp = interpolate.UnivariateSpline(w_frog, phase_frog)
            phase = fun_temp(solveparam.w)
            phase[np.isnan(phase)] = 0
            E0f = amplitude * np.exp(1j * phase)
            self.E0t = np.real(np.fft.fftshift(np.fft.fft(E0f)))
            E0t = self.E0t / np.max(self.E0t)
            self.E0f = ifft(E0t)


gas_instance = gas(
    gas_type='helium',
    ionorder=1,
    pressure=3,
    ionization_type='PPT',
)

e = 1.60217646e-19
I_H = 13.6 * e
a_B = 0.529e-10
me = 9.10938356e-31


# @profile
def electron_polar(solveParam, Et, gas, gasPCF, ADK_flag=0):
    num = len(solveParam.t)
    t = solveParam.t
    Cn = gas.Cn
    if gas.ionorder < 0.1:
        P = 0
        Ne = 0
        Ni = 0
        Na = gasPCF.N0
    else:

        W = np.zeros((int(gas.ionorder), num))
        k = np.zeros((int(gas.ionorder), num))
        w_t = np.zeros((int(gas.ionorder), num))
        if ADK_flag == 1:
            w_t[0, :] = 4 * gas.w_p[:, 0] * (2 * me * gas.I_p[0]) ** 0.5 / (e * np.abs(Et))
            W[0, :] = Cn * w_t[0, :] ** (2 * gas.n_star - 1) * np.exp(-w_t[0, :] / 3)
        else:
            Intensity = cal_intensity(Et, Cn)

            W[0, :] = speical_interp1d(gas.n_star, gas.temp_fun, Intensity)

        # W[np.logical_or(np.isnan(W), np.isinf(W))] = 0
        k = real_cumtrapz(W[0, :], t)
        k[np.logical_or(np.isnan(k), np.isinf(k))] = 0
        Na = np.exp(-np.abs(k))
        Ni = 1 - Na
        Ne = 1 * Ni
        # indx_choose = lambda x: np.logical_or(np.isnan(x), x < 0)
        Na[np.logical_or(np.isnan(Na), Na < 0)] = 1
        Na = gasPCF.N0 * Na
        Ni[np.logical_or(np.isnan(Ni), Ni < 0)] = 0
        Ni = gasPCF.N0 * Ni
        Ne[np.logical_or(np.isnan(Ne), Ne < 0)] = 0
        Ne = gasPCF.N0 * Ne
        delNdeltdivE = gas.I_p[0] * W[0, :] * Na
        delNdeltdivE = delNdeltdivE / Et
        delNdeltdivE[np.logical_or(np.isnan(delNdeltdivE), np.isinf(delNdeltdivE))] = 0
        delNdeltdivE[np.logical_or(np.isnan(delNdeltdivE), np.isinf(delNdeltdivE))] = 0
        P_real = real_cumtrapz(
            np.real(1 / epsi0 * (delNdeltdivE + e ** 2 / me * real_cumtrapz(np.real(Ne * Et), t))),
            t)
        P_imag = real_cumtrapz(
            np.imag(1 / epsi0 * (delNdeltdivE + e ** 2 / me * real_cumtrapz(np.imag(Ne * Et), t))),
            t)
        # P = P_real + 1j * P_imag
        # P = P * np.exp(-0.5 * (t / (0.9 * t[-1])) ** 100)
        P = cal(P_real, P_imag, t)

    return P, Ne, Ni, Na


def speical_interp1d(x, temp_fun, x_new):
    # fun_temp = interpolate.interp1d(x, y, kind='cubic')
    y_new = np.zeros_like(x_new)
    indx = np.logical_and(x_new >= np.min(x), x_new <= np.max(x))
    y_new[indx] = temp_fun(x_new[indx])
    return y_new


@jit(nopython=True, parallel=True)
def cal(x_new_real, x_new_imag, x):
    x_new = x_new_real + 1j * x_new_imag
    return x_new * np.exp(-0.5 * (x / (0.9 * x[-1])) ** 100)


@jit(nopython=True, parallel=True)
def cal_intensity(Et, Cn):
    return np.real(Et) ** 2 * c * epsi0 * Cn / 2 * 1e-4
