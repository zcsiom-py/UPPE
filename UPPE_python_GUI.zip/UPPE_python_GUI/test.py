import numpy as np
from scipy.interpolate import CubicSpline
import time
import matplotlib.pyplot as plt
from numba import jit
import time

x = np.linspace(0, 1, num=256)
y = np.sin(x)

x_new = np.random.random(2 ** 15)

a = np.random.random(255)
b = np.random.random(255)
c = np.random.random(255)
d = np.random.random(255)
indx = np.arange(0, len(x))


@jit(nopython=True)
def evaluate(a, b, c, d, x_new, x):
    y_new = np.zeros_like(x_new)
    for i in range(len(x_new)):  # 修改遍历方式，把对于x_new的遍历转化对于间断点的遍历，对于x的遍历可以同时求位于x_i和x_i+1中的所有数据点。

        num_int = indx[x < x_new[i]][-1]
        y_new[i] = a[num_int - 1] + b[num_int - 1] * (x_new[i] - x[num_int]) + c[num_int - 1] * (
                x_new[i] - x[num_int - 1]) ** 2 + d[num_int - 1]
    return y_new


start = time.time()
for i in range(100):
    y_new = evaluate(a, b, c, d, x_new)
end = time.time()
print(end - start)

plt.figure()
plt.plot(x_new, y_new)
plt.show()
